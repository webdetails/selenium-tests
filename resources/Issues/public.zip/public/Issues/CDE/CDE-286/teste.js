lib('cdf-env.js');


load('../../cgg/cgg-implementation.js');
var render_teste = {
	type: "cggDial",
	name: "render_teste",
	priority: 5,
	executeAtStart: true,
	parameter: "25",
	colors: ["red","yellow","green"],
	intervals: ["0","10","20","30"],
	htmlObject: "${p:Linha_Nome}",
	listeners: [],
	width: 300,
	height: 300
};



cgg.render(render_teste);
