/*!
 * HITACHI VANTARA PROPRIETARY AND CONFIDENTIAL
 *
 * Copyright 2002 - 2019 Hitachi Vantara. All rights reserved.
 *
 * NOTICE: All information including source code contained herein is, and
 * remains the sole property of Hitachi Vantara and its licensors. The intellectual
 * and technical concepts contained herein are proprietary and confidential
 * to, and are trade secrets of Hitachi Vantara and may be covered by U.S. and foreign
 * patents, or patents in process, and are protected by trade secret and
 * copyright laws. The receipt or possession of this source code and/or related
 * information does not convey or imply any rights to reproduce, disclose or
 * distribute its contents, or to manufacture, use, or sell anything that it
 * may describe, in whole or in part. Any reproduction, modification, distribution,
 * or public display of this information without the express written authorization
 * from Hitachi Vantara is strictly prohibited and in violation of applicable laws and
 * international treaties. Access to the source code contained herein is strictly
 * prohibited to anyone except those individuals and entities who have executed
 * confidentiality and non-disclosure agreements or other agreements with Hitachi Vantara,
 * explicitly covering such access.
 */

/* global params */

(function() {

  lib("cgg-env.js");

  cgg.init();

  // Additional AMD configuration

  var basePathAnalyzer = "/plugin/analyzer/";

  var requireCfg = {
    paths:  {
      "pentaho/analyzer": basePathAnalyzer + "scripts/compressed",
      "pentaho/analyzer/visual/config": basePathAnalyzer + "scripts/visual/config",
      "pentaho/analyzer/resources": basePathAnalyzer + "resources"
    },
    config: {
      "pentaho/environment": {
        application: "pentaho/analyzer"
      },
      "pentaho/modules": {
        "pentaho/analyzer/visual/config": {type: "pentaho/config/spec/IRuleSet"}
      }
    },
    bundles: {
      "pentaho/analyzer/API": [
        "pentaho/analyzer/visual/OptionsAnnotation",
        "pentaho/analyzer/visual/utils"
      ]
    }
  };

  require.config(requireCfg);

  // Template Params BEG
  var typeId = "pentaho/visual/models/BarHorizontal";
  var width = 981;
  var height = 733;
  var dataSpec = /* <?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<message id="successGenerateReport" type="success" xmlns="http://www.pentaho.com"/>
 */{"layout":{"meas":["[MEASURE:0]"],"rows":["[Markets].[Territory]"],"cols":["[Product].[Line]"]},"formatStrings":{"[MEASURE:0]":"#,###","thousandSeparator":".","decimalPlaceholder":",","currencySymbol":"\u20ac"},"model":{"format":{"number":{"style":{"currency":"\u20ac","decimal":",","group":"."}}},"attrs":[{"hierarchyOrdinal":0,"members":[{"v":"[Markets].[APAC]","f":"APAC"},{"v":"[Markets].[EMEA]","f":"EMEA"},{"v":"[Markets].[Japan]","f":"Japan"},{"v":"[Markets].[NA]","f":"NA"}],"name":"[Markets].[Territory]","isKey":true,"hierarchyName":"[Markets]","label":"Territory","type":"string"},{"hierarchyOrdinal":0,"members":[{"v":"[Product].[Classic Cars]","f":"Classic Cars"},{"v":"[Product].[Motorcycles]","f":"Motorcycles"},{"v":"[Product].[Planes]","f":"Planes"},{"v":"[Product].[Ships]","f":"Ships"},{"v":"[Product].[Trains]","f":"Trains"},{"v":"[Product].[Trucks and Buses]","f":"Trucks and Buses"},{"v":"[Product].[Vintage Cars]","f":"Vintage Cars"}],"name":"[Product].[Line]","isKey":true,"hierarchyName":"[Product]","label":"Line","type":"string"},{"isPercent":false,"name":"[MEASURE:0]","format":{"number":{"mask":"#,###"}},"label":"Quantity","type":"number"}]},"rows":[{"c":[{"v":"[Markets].[APAC]","f":"APAC"},{"v":3852,"f":"3.852"},{"v":1852,"f":"1.852"},{"v":1330,"f":"1.330"},{"v":428,"f":"428"},{"v":139,"f":"139"},{"v":1380,"f":"1.380"},{"v":3897,"f":"3.897"}]},{"c":[{"v":"[Markets].[EMEA]","f":"EMEA"},{"v":18292,"f":"18.292"},{"v":5106,"f":"5.106"},{"v":5513,"f":"5.513"},{"v":4808,"f":"4.808"},{"v":1544,"f":"1.544"},{"v":4655,"f":"4.655"},{"v":9660,"f":"9.660"}]},{"c":[{"v":"[Markets].[Japan]","f":"Japan"},{"v":1327,"f":"1.327"},{"v":629,"f":"629"},{"v":1224,"f":"1.224"},{"v":382,"f":"382"},{"v":223,"f":"223"},{"v":517,"f":"517"},{"v":621,"f":"621"}]},{"c":[{"v":"[Markets].[NA]","f":"NA"},{"v":12081,"f":"12.081"},{"v":5121,"f":"5.121"},{"v":3793,"f":"3.793"},{"v":2881,"f":"2.881"},{"v":912,"f":"912"},{"v":4449,"f":"4.449"},{"v":8715,"f":"8.715"}]}],"version":3,"cols":[{"dataReq":[{"level":"[Markets].[Territory]","id":"rows"}],"id":"[Markets].[Territory]","label":"Territory","attr":"[Markets].[Territory]","type":"string"},{"dataReq":[{"level":"[Product].[Line]","id":"columns"},{"level":"[Measures].[MeasuresLevel]","id":"measures"}],"c":["[Product].[Classic Cars]"],"id":"[Product].[Classic Cars]~[MEASURE:0]","label":"Classic Cars~Quantity","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Product].[Line]","id":"columns"},{"level":"[Measures].[MeasuresLevel]","id":"measures"}],"c":["[Product].[Motorcycles]"],"id":"[Product].[Motorcycles]~[MEASURE:0]","label":"Motorcycles~Quantity","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Product].[Line]","id":"columns"},{"level":"[Measures].[MeasuresLevel]","id":"measures"}],"c":["[Product].[Planes]"],"id":"[Product].[Planes]~[MEASURE:0]","label":"Planes~Quantity","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Product].[Line]","id":"columns"},{"level":"[Measures].[MeasuresLevel]","id":"measures"}],"c":["[Product].[Ships]"],"id":"[Product].[Ships]~[MEASURE:0]","label":"Ships~Quantity","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Product].[Line]","id":"columns"},{"level":"[Measures].[MeasuresLevel]","id":"measures"}],"c":["[Product].[Trains]"],"id":"[Product].[Trains]~[MEASURE:0]","label":"Trains~Quantity","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Product].[Line]","id":"columns"},{"level":"[Measures].[MeasuresLevel]","id":"measures"}],"c":["[Product].[Trucks and Buses]"],"id":"[Product].[Trucks and Buses]~[MEASURE:0]","label":"Trucks and Buses~Quantity","attr":"[MEASURE:0]","type":"number"},{"dataReq":[{"level":"[Product].[Line]","id":"columns"},{"level":"[Measures].[MeasuresLevel]","id":"measures"}],"c":["[Product].[Vintage Cars]"],"id":"[Product].[Vintage Cars]~[MEASURE:0]","label":"Vintage Cars~Quantity","attr":"[MEASURE:0]","type":"number"}],"colors":{}};
  var pluginData = [{"labelsOption":"insideEnd"}];
  var chartOptions = {"labelFontFamily":"Default","legendFontFamily":"Default","showLegend":"true","legendStyle":"PLAIN","autoRange":"true","maxValues":"100","lineShape":"CIRCLE","lineWidth":"2","labelSize":"12","backgroundColorEnd":"#ffffff","labelStyle":"PLAIN","autoRangeSecondary":"true","legendColor":"#000000","backgroundFill":"NONE","backgroundColor":"#ffffff","displayUnitsSecondary":"UNITS_0","multiChartRangeScope":"GLOBAL","sizeByNegativesMode":"NEG_LOWEST","maxChartsPerRow":"3","legendSize":"12","labelColor":"#000000","customChartType":"pentaho/visual/models/BarHorizontal","legendBackgroundColor":"#98fb98","chartType":"CUSTOM","displayUnits":"UNITS_0","emptyCellMode":"GAP","legendPosition":"BOTTOM","vizApiVersion":"3.0"};
  var visualMap = {"measures":["[MEASURE:0]"],"columns":["[Product].[Line]"],"rows":["[Markets].[Territory]"]};
  // Template Params END

  require([
    "cdf/lib/CCC/def",
    "pentaho/data/Table",
    "pentaho/visual/util",
    "pentaho/analyzer/visual/utils",
    "pentaho/visual/ModelAdapter"
  ], function(def, Table, visualUtil, localVisualUtils, ModelAdapter) {

    try {
      def.setDebug(cgg.debug);

      var domContainer = document.documentElement;

      // Specify dimensions in the wrapper's dom element.
      domContainer.setAttribute("width",  String(width));
      domContainer.setAttribute("height", String(height));

      var view;
      var model;

      visualUtil.getModelAndDefaultViewClassesAsync(typeId)
        .then(function(classes) {
          model = createModel(classes.Model);
          var modelAdapter = createModelAdapter(model, ModelAdapter);

          view = new classes.View({
            model: model,
            domContainer: domContainer
          });

          return model.update();
        })
        .then(function() {
          // Set the SVG element with the final/grown chart width/height
          // so that the PNGTranscoder can detect the actual image size.
          var cccChart  = view._chart;
          var basePanel = cccChart && cccChart.basePanel;

          domContainer.setAttribute("width", String(basePanel ? basePanel.width : model.width));
          domContainer.setAttribute("height", String(basePanel ? basePanel.height : model.height));
        })
        ["catch"](function(ex) {
          print(ex.message + ex.stack);
        });

    } catch(ex) {
      print(ex.message + ex.stack);
    }

    function createModel(VizModel) {

      var modelSpec = pluginData[0] || {};

      modelSpec.isAutoUpdate = false;
      modelSpec.width = width;
      modelSpec.height = height;

      // Mixin Chart Options
      def.copyOwn(modelSpec, generateModelPropsImplied(VizModel.type));

      // CCC wrapper specific CGG option
      var multiChartOverflow = params.get("multiChartOverflow");
      if(multiChartOverflow)
        modelSpec.multiChartOverflow = multiChartOverflow.toLowerCase();

      return new VizModel(modelSpec);
    }

    function createModelAdapter(model, BaseVizModelAdapter) {

      // Create the class dynamically.
      var VizModelAdapter = BaseVizModelAdapter.extend({
        $type: {
          props: {
            model: {valueType: model.constructor}
          }
        }
      });

      var modelAdapterSpec = {
        model: model,
        data: new Table(dataSpec)
      };

      addVisualRoleMappingsToVisualSpec(VizModelAdapter.type, modelAdapterSpec);

      return new VizModelAdapter(modelAdapterSpec);
    }

    function generateModelPropsImplied(modelType) {

      var vizProps;
      var annotationSpec = localVisualUtils.getVizOptionsAnnotation(modelType.id);
      var handler = annotationSpec && annotationSpec.generateOptionsFromAnalyzerState;
      if(handler) {
        vizProps = handler(getReportMock());
      }

      return vizProps || {};
    }

    function getReportMock() {

      var attrs = [];

      for(var p in chartOptions) {
        if(def.hasOwn(chartOptions, p)) {
          attrs.push({
            nodeName:  p,
            nodeValue: chartOptions[p]
          });
        }
      }

      return {
        reportDoc: {
          getChartOptions: function() {
            return {attributes: attrs};
          }
        }
      };
    }

    function addVisualRoleMappingsToVisualSpec(modelAdapterType, spec) {
      modelAdapterType.eachVisualRole(function(propType) {
        var name = propType.name;
        spec[name] = {fields: visualMap[name] || []};
      });
    }

  }, function(ex) {
    print(ex.message + ex.stack);
  });

  // Process any async tasks installed by setTimeout
  cgg.run();

}());
